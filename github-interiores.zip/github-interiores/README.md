# Casa Viva Interiores

Site de um estúdio de design de interiores em Maputo, Moçambique, com serviços, pedido de orçamento por WhatsApp, projetos, "Sobre nós" e contacto.

## Ficheiros

- `index.html`: o site completo (HTML, CSS e JavaScript).
- `imagens/`: ilustrações do site (sala, projetos, antes e depois e galeria).

## Trocar por fotografias reais

Carregue as suas fotos para a pasta `imagens/` (por exemplo `t2.jpg`) e, no `index.html`, troque `imagens/projeto-t2.svg` por `imagens/t2.jpg`. Use fotos suas ou com licença.

## Como editar

No bloco `<script>` do `index.html`:

- `TELEFONE`: número de WhatsApp com indicativo (258), sem `+` nem espaços.
- `SERVICOS`: nomes, descrições e preços (em MT).

Altere também a morada, o email, os projetos e o texto de "Sobre nós".

## Como publicar (GitHub Pages)

1. No repositório, vá a **Settings → Pages**.
2. Em **Branch**, escolha `main` e a pasta `/ (root)`. Guarde.
3. Após 1 a 2 minutos, o site fica em `https://SEU-UTILIZADOR.github.io/NOME-DO-REPOSITORIO/`.
